document.addEventListener("DOMContentLoaded", function () {
    loadCars();
    
    // Check if #contact-form exists before adding event listener
    const contactForm = document.querySelector("#contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", submitForm);
    }

    // Add event listeners for search and filter
    document.getElementById("search").addEventListener("input", filterCars);
    document.getElementById("filterPrice").addEventListener("change", filterCars);
});

const cars = [
    { model: "BMW", price: 70000, image: "images/BMW M8.avif", link: "bmw.html" },
    { model: "TATA", price: 50000, image: "images/Tata-Punch-Camo.jpg", link: "tata.html" },
    { model: "FERRARI", price: 85000, image: "images/ferrari.jpg", link: "ferrari.html" },
    { model: "MERCEDES-BENZ", price: 60000, image: "images/mercedes.jpg", link: "mercedes.html" },
];

function selectCarModel() {
    const selectedModel = document.getElementById('search-model').value;
    if (selectedModel) {
        alert(`You selected: ${selectedModel}`);
    } else {
        alert('Please select a car model.');
    }
}

function loadCars() {
    const carList = document.querySelector("#car-list");
    carList.innerHTML = "";
    cars.forEach(car => {
        carList.innerHTML += `
            <div class="car">
                <img src="${car.image}" alt="${car.model}" style="cursor: pointer;" onclick="window.location.href='${car.link}';">
                <h3>${car.model}</h3>
                <p>Price: $${car.price.toLocaleString()}</p>
            </div>
        `;
    });
}

function filterCars() {
    const searchQuery = document.getElementById("search").value.toLowerCase();
    const priceFilter = document.getElementById("filterPrice").value;

    let filteredCars = cars.filter(car => car.model.toLowerCase().includes(searchQuery));

    if (priceFilter !== "all") {
        filteredCars = filteredCars.filter(car => {
            if (priceFilter === "low") return car.price < 30000;
            if (priceFilter === "mid") return car.price >= 30000 && car.price <= 60000;
            if (priceFilter === "high") return car.price > 60000;
        });
    }

    const carList = document.querySelector("#car-list");
    carList.innerHTML = "";
    filteredCars.forEach(car => {
        carList.innerHTML += `
            <div class="car">
                <img src="${car.image}" alt="${car.model}" style="cursor: pointer;" onclick="window.location.href='${car.link}';">
                <h3>${car.model}</h3>
                <p>Price: $${car.price.toLocaleString()}</p>
            </div>
        `;
    });
}

/*function submitForm(event) {
    event.preventDefault();
    alert("Thank you for your message! We will get back to you soon.");
}*/
function submitForm(event) {
    event.preventDefault(); // Prevent default form submission behavior

    // Get form data
    let form = document.getElementById("contactForm"); // Ensure your form has this ID
    let formData = new FormData(form);

    // Send form data using Fetch API
    fetch('/submit_contact', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert("Thank you for your message! We will get back to you soon.");
        form.reset(); // ✅ Clear all input fields after successful submission
    })
    .catch(error => console.error("Error:", error));
}


function scrollToSection(id) {
    document.getElementById(id).scrollIntoView({ behavior: "smooth" });
}
