from flask import Flask, request, jsonify, send_from_directory
from flask_mysqldb import MySQL

app = Flask(__name__)

# ==================== MySQL Config ====================
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Navee@03'  # Change if needed
app.config['MYSQL_DB'] = 'carshowroom'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)

# ==================== Route: Home ====================
@app.route('/')
def home():
    return send_from_directory('.', 'index1.html')

# ==================== Route: Contact Form Handler ====================
@app.route('/submit_contact', methods=['POST'])
def submit_contact():
    try:
        # Get data from frontend (JSON or form-data)
        if request.content_type == 'application/json':
            data = request.get_json()
            name = data.get('name')
            email = data.get('email')
            message = data.get('message')
        else:
            name = request.form.get('name')
            email = request.form.get('email')
            message = request.form.get('message')

        # Debug log
        print(f"Received: Name={name}, Email={email}, Message={message}")

        if not all([name, email, message]):
            return jsonify({'error': 'All fields are required.'}), 400

        # Insert into DB
        conn = mysql.connection
        cursor = conn.cursor()
        cursor.execute("INSERT INTO contact (name, email, message) VALUES (%s, %s, %s)", (name, email, message))
        conn.commit()
        print("Contact form data saved successfully.")
        return jsonify({'message': 'Form submitted successfully!'}), 200

    except Exception as e:
        print("Error:", e)
        return jsonify({'error': f"Failed to submit form: {str(e)}"}), 500

    finally:
        if 'cursor' in locals():
            cursor.close()

# ==================== Route: Serve All Frontend Files ====================
@app.route('/<path:filename>')
def serve_static_file(filename):
    return send_from_directory('.', filename)

# ==================== Run the Flask App ====================
if __name__ == '__main__':
    app.run(debug=True)
