document.addEventListener("DOMContentLoaded", function () {
    loadCars(); // Load cars from the backend
    
    // Check if #contact-form exists before adding event listener
    const contactForm = document.querySelector("#contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", submitForm);
    }

    // Add event listeners for search and filter
    document.getElementById("search").addEventListener("input", filterCars);
    document.getElementById("filterPrice").addEventListener("change", filterCars);
});

// Function to load cars from the backend API
function loadCars() {
    const carList = document.querySelector("#car-list");
    carList.innerHTML = ""; // Clear existing car list

    fetch('http://127.0.0.1:5000/api/cars') // API endpoint to fetch cars
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse JSON data
        })
        .then(cars => {
            cars.forEach(car => {
                carList.innerHTML += `
                    <div class="car">
                        <img src="${car.image || 'default-image.jpg'}" alt="${car.model}" style="cursor: pointer;" onclick="window.location.href='${car.link || '#'}';">
                        <h3>${car.model}</h3>
                        <p>Price: $${car.price.toLocaleString()}</p>
                    </div>
                `;
            });
        })
        .catch(error => {
            console.error('Error fetching cars:', error);
            carList.innerHTML = '<p>Failed to load cars. Please try again later.</p>';
        });
}

// Function to filter cars based on search input and price filter
function filterCars() {
    const searchQuery = document.getElementById("search").value.toLowerCase();
    const priceFilter = document.getElementById("filterPrice").value;

    fetch('http://127.0.0.1:5000/api/cars') // Fetch cars again for filtering
        .then(response => response.json())
        .then(cars => {
            let filteredCars = cars.filter(car => car.model.toLowerCase().includes(searchQuery));

            if (priceFilter !== "all") {
                filteredCars = filteredCars.filter(car => {
                    if (priceFilter === "low") return car.price < 30000;
                    if (priceFilter === "mid") return car.price >= 30000 && car.price <= 60000;
                    if (priceFilter === "high") return car.price > 60000;
                });
            }

            const carList = document.querySelector("#car-list");
            carList.innerHTML = ""; // Clear existing car list
            filteredCars.forEach(car => {
                carList.innerHTML += `
                    <div class="car">
                        <img src="${car.image || 'default-image.jpg'}" alt="${car.model}" style="cursor: pointer;" onclick="window.location.href='${car.link || '#'}';">
                        <h3>${car.model}</h3>
                        <p>Price: $${car.price.toLocaleString()}</p>
                    </div>
                `;
            });
        })
        .catch(error => {
            console.error('Error filtering cars:', error);
        });
}

function submitForm(event) {
    event.preventDefault();
    alert("Thank you for your message! We will get back to you soon.");
}

function scrollToSection(id) {
    document.getElementById(id).scrollIntoView({ behavior: "smooth" });
}